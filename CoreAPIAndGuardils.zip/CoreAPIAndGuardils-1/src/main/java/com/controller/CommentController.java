package com.controller;

import com.dto.CommentRequest;
import com.entity.Comment;
import com.service.CommentService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/posts")
public class CommentController {

    private final CommentService commentService;

    public CommentController(CommentService commentService) {
        this.commentService = commentService;
    }

    @PostMapping("/{postId}/comments")
    public Comment addComment(@PathVariable Long postId,
                              @RequestBody CommentRequest request) {
        return commentService.addComment(postId, request);
    }
}