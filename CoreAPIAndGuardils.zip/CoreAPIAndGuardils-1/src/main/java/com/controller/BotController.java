package com.controller;

import com.entity.Bot;
import com.repository.BotRepository;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/bots")
public class BotController {

    private final BotRepository botRepository;

    public BotController(BotRepository botRepository) {
        this.botRepository = botRepository;
    }

    @PostMapping
    public Bot createBot(@RequestBody Bot bot) {
        return botRepository.save(bot);
    }
}