package com.controller;

import com.dto.PostRequest;
import com.entity.Post;
import com.service.PostService;
import com.service.RedisService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/posts")
public class PostController {

    private final PostService postService;
    private final RedisService redisService;

    public PostController(PostService postService, RedisService redisService) {
        this.postService = postService;
        this.redisService = redisService;
    }

    @PostMapping
    public Post createPost(@RequestBody PostRequest request) {
        return postService.createPost(request);
    }

    @PostMapping("/{postId}/like")
    public String likePost(@PathVariable Long postId) {
        redisService.incrementVirality(postId, 20);
        return "Liked";
    }
}