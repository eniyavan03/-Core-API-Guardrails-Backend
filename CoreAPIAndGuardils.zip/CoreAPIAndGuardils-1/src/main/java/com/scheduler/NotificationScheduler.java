package com.scheduler;

import com.service.RedisService;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.Set;

@Component
public class NotificationScheduler {

    private final RedisService redisService;

    public NotificationScheduler(RedisService redisService) {
        this.redisService = redisService;
    }

    // Runs every 5 minutes
    @Scheduled(fixedRate = 300000)
    public void processNotifications() {

        System.out.println("Running Notification Scheduler...");

        Set<String> users = redisService.getTrackedUsers();

        if (users == null || users.isEmpty()) {
            return;
        }

        for (String userIdStr : users) {

            Long userId = Long.parseLong(userIdStr);

            Long count = redisService.getNotificationCount(userId);

            if (count != null && count > 0) {

                System.out.println(
                        "Summarized Push Notification: User "
                                + userId + " has "
                                + count + " new interactions."
                );

                // clear notifications
                redisService.clearNotifications(userId);
            }
        }
    }
}