package com.dto;

public class CommentRequest {

    private String username; // user comment
    private String botName;  // bot comment
    private String content;
    private int depth;

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public String getBotName() { return botName; }
    public void setBotName(String botName) { this.botName = botName; }

    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }

    public int getDepth() { return depth; }
    public void setDepth(int depth) { this.depth = depth; }
}