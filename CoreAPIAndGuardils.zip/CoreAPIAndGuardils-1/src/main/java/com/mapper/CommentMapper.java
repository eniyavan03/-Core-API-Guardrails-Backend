package com.mapper;

import com.dto.CommentRequest;
import com.entity.Comment;

public class CommentMapper {

    public static Comment toUserComment(CommentRequest req, Long userId, Long postId) {
        Comment c = new Comment();
        c.setPostId(postId);
        c.setAuthorType("USER");
        c.setAuthorId(userId);
        c.setContent(req.getContent());
        c.setDepthLevel(req.getDepth());
        return c;
    }

    public static Comment toBotComment(CommentRequest req, Long botId, Long postId) {
        Comment c = new Comment();
        c.setPostId(postId);
        c.setAuthorType("BOT");
        c.setAuthorId(botId);
        c.setContent(req.getContent());
        c.setDepthLevel(req.getDepth());
        return c;
    }
}