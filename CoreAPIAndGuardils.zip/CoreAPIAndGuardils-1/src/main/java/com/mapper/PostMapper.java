package com.mapper;

import com.dto.PostRequest;
import com.entity.Post;

public class PostMapper {

    public static Post toEntity(PostRequest request, Long userId) {

        Post post = new Post();
        post.setAuthorType("USER");
        post.setAuthorId(userId);
        post.setContent(request.getContent());

        return post;
    }
}