package com.service;

import com.dto.PostRequest;
import com.entity.Post;
import com.entity.User;
import com.mapper.PostMapper;
import com.repository.PostRepository;
import com.repository.UserRepository;
import org.springframework.stereotype.Service;

@Service
public class PostService {

    private final PostRepository postRepository;
    private final UserRepository userRepository;
    private final RedisService redisService;

    public PostService(PostRepository postRepository,
                       UserRepository userRepository,
                       RedisService redisService) {
        this.postRepository = postRepository;
        this.userRepository = userRepository;
        this.redisService = redisService;
    }

    public Post createPost(PostRequest request) {

        User user = userRepository.findByUsername(request.getUsername())
                .orElseThrow(() -> new RuntimeException("User not found"));

        Post post = PostMapper.toEntity(request, user.getId());

        Post saved = postRepository.save(post);

        redisService.incrementVirality(saved.getId(), 0);

        return saved;
    }
}