package com.service;

import org.springframework.stereotype.Service;

@Service
public class NotificationService {

    private final RedisService redisService;

    public NotificationService(RedisService redisService) {
        this.redisService = redisService;
    }

    public void handleNotification(Long userId, String message) {

        // Check if user has cooldown
        if (redisService.hasUserNotifCooldown(userId)) {

            // Push to Redis queue
            redisService.pushNotification(userId, message);

            // Track user for scheduler
            redisService.trackUser(userId);

        } else {

            // Send immediately (simulate)
            System.out.println("Push Notification Sent to User " + userId + ": " + message);

            // Set cooldown
            redisService.setUserNotifCooldown(userId);
        }
    }
}