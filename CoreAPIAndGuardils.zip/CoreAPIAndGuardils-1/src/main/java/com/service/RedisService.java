package com.service;

import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import java.util.Set;
import java.util.concurrent.TimeUnit;

@Service
public class RedisService {

    private final StringRedisTemplate redisTemplate;

    public RedisService(StringRedisTemplate redisTemplate) {
        this.redisTemplate = redisTemplate;
    }

    // ===============================
    // VIRALITY SCORE
    // ===============================
    public void incrementVirality(Long postId, int score) {
        String key = "post:" + postId + ":virality_score";
        redisTemplate.opsForValue().increment(key, score);
    }

    // ===============================
    // BOT COUNT (HORIZONTAL CAP)
    // ===============================
    public long incrementBotCount(Long postId) {
        String key = "post:" + postId + ":bot_count";
        return redisTemplate.opsForValue().increment(key);
    }

    // ===============================
    // COOLDOWN (BOT ↔ USER)
    // ===============================
    public boolean isCooldownActive(Long botId, Long userId) {
        String key = "cooldown:bot_" + botId + ":user_" + userId;
        return redisTemplate.hasKey(key);
    }

    public void setCooldown(Long botId, Long userId) {
        String key = "cooldown:bot_" + botId + ":user_" + userId;
        redisTemplate.opsForValue().set(key, "1", 10, TimeUnit.MINUTES);
    }

    // ===============================
    // USER NOTIFICATION COOLDOWN
    // ===============================
    public boolean hasUserNotifCooldown(Long userId) {
        String key = "notif:cooldown:user_" + userId;
        return redisTemplate.hasKey(key);
    }

    public void setUserNotifCooldown(Long userId) {
        String key = "notif:cooldown:user_" + userId;
        redisTemplate.opsForValue().set(key, "1", 15, TimeUnit.MINUTES);
    }

    // ===============================
    // PENDING NOTIFICATIONS (LIST)
    // ===============================
    public void pushNotification(Long userId, String message) {
        String key = "user:" + userId + ":pending_notifs";
        redisTemplate.opsForList().rightPush(key, message);
    }

    public Long getNotificationCount(Long userId) {
        String key = "user:" + userId + ":pending_notifs";
        return redisTemplate.opsForList().size(key);
    }

    public void clearNotifications(Long userId) {
        String key = "user:" + userId + ":pending_notifs";
        redisTemplate.delete(key);
    }

    // ===============================
    // TRACK USERS (SET)
    // ===============================
    public void trackUser(Long userId) {
        redisTemplate.opsForSet().add("users_with_notifications", userId.toString());
    }

    public Set<String> getTrackedUsers() {
        return redisTemplate.opsForSet().members("users_with_notifications");
    }
}