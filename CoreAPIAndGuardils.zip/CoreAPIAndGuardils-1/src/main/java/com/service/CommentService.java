package com.service;

import com.dto.CommentRequest;
import com.entity.*;
import com.mapper.CommentMapper;
import com.repository.*;
import org.springframework.stereotype.Service;

@Service
public class CommentService {

    private final CommentRepository commentRepository;
    private final PostRepository postRepository;
    private final UserRepository userRepository;
    private final BotRepository botRepository;
    private final RedisService redisService;
    private final NotificationService notificationService;

    public CommentService(CommentRepository commentRepository,
                          PostRepository postRepository,
                          UserRepository userRepository,
                          BotRepository botRepository,
                          RedisService redisService,
                          NotificationService notificationService) {
        this.commentRepository = commentRepository;
        this.postRepository = postRepository;
        this.userRepository = userRepository;
        this.botRepository = botRepository;
        this.redisService = redisService;
        this.notificationService = notificationService;
    }

    // 🔥 ENTRY POINT
    public Comment addComment(Long postId, CommentRequest request) {

        if (request.getUsername() != null && request.getBotName() != null) {
            throw new RuntimeException("Send only one: username OR botName");
        }

        if (request.getUsername() != null) {
            return handleUserComment(postId, request);
        }

        if (request.getBotName() != null) {
            return handleBotComment(postId, request);
        }

        throw new RuntimeException("Invalid request");
    }

    // ===============================
    // USER COMMENT
    // ===============================
    private Comment handleUserComment(Long postId, CommentRequest request) {

        User user = userRepository.findByUsername(request.getUsername())
                .orElseThrow(() -> new RuntimeException("User not found"));

        Comment comment = CommentMapper.toUserComment(request, user.getId(), postId);

        Comment saved = commentRepository.save(comment);

        // Virality +50
        redisService.incrementVirality(postId, 50);

        return saved;
    }

    // ===============================
    // BOT COMMENT
    // ===============================
    private Comment handleBotComment(Long postId, CommentRequest request) {

        Post post = postRepository.findById(postId)
                .orElseThrow(() -> new RuntimeException("Post not found"));

        Bot bot = botRepository.findByName(request.getBotName())
                .orElseThrow(() -> new RuntimeException("Bot not found"));

        // ❌ Depth limit
        if (request.getDepth() > 20) {
            throw new RuntimeException("Max depth exceeded");
        }

        // ❌ Bot limit (100)
        long count = redisService.incrementBotCount(postId);
        if (count > 100) {
            throw new RuntimeException("Too many bot replies");
        }

        // ❌ Cooldown
        if ("USER".equals(post.getAuthorType())) {

            Long userId = post.getAuthorId();

            if (redisService.isCooldownActive(bot.getId(), userId)) {
                throw new RuntimeException("Cooldown active");
            }

            redisService.setCooldown(bot.getId(), userId);

            // 🔔 Notification
            notificationService.handleNotification(userId,
                    "Bot " + bot.getName() + " replied");
        }

        Comment comment = CommentMapper.toBotComment(request, bot.getId(), postId);

        Comment saved = commentRepository.save(comment);

        // Virality +1
        redisService.incrementVirality(postId, 1);

        return saved;
    }
}